import pymongo
import re
connection = pymongo.MongoClient('mongodb+srv://user01:krtfall2019@shivam-c1-qds0d.mongodb.net/test?retryWrites=true&w=majority')
import json
database = connection['extinctlanguages']
collection = database['data']

from bson.json_util import dumps
print('connection created')

def get_multiple_data(query):
    """
    get document data by document ID:
	return:
    """
    myquery = { "Description of the location": { "$regex": str(query)+'.*',"$options" : '-i' } }
    
    
    mydoc = collection.find(myquery)
    total = collection.count(myquery)
    
   # l=[]
   # for i in mydoc:
   #      print(type(i))
   #      l.append(str(i))
         
    print(total)
   
    return dumps(mydoc)

def get_multiple_data1(query):
    """
    get document data by document ID:
	return:
    """
    myquery = { "ID": int(query) }
    
    
    mydoc = collection.find(myquery)
    total = collection.count(myquery)
    
   # l=[]
   # for i in mydoc:
   #      print(type(i))
   #      l.append(str(i))
         
    print(total)
   
    return dumps(mydoc)

def get_multiple_data2(query1,query2):
    """
    get document data by document ID:
	return:
    """
    myquery = {"$and":[ {"Latitude":{"$lt": query1+3}}, {"Latitude":{"$gte": query1-3}},{"Longitude":{"$lt": query2+20}}, {"Longitude":{"$gte": query2-20}}]}
    
    mydoc = collection.find(myquery).limit(50)
    total = collection.count(myquery)
    
   # l=[]
   # for i in mydoc:
   #      print(type(i))
   #      l.append(str(i))
         
    print(total)
   
    return dumps(mydoc)
        
def get_multiple_data3(query1,query2):
    """
    get document data by document ID:
	return:
    """    
    myquery = { "ID": int(query2) }
    collection.update(myquery,{"$push":{"comment": query1}})
    mydoc = collection.find(myquery)
    total = collection.count(myquery)
    
   # l=[]
   # for i in mydoc:
   #      print(type(i))
   #      l.append(str(i))
         
    print(total)
   
    return dumps(mydoc)        
# CLOSE DATABASE
#get_multiple_data()
#connection.close()


