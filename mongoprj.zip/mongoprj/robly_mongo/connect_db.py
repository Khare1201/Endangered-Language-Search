import pymongo

connection = pymongo.MongoClient('mongodb+srv://user01:krtfall2019@shivam-c1-qds0d.mongodb.net/test?retryWrites=true&w=majority')

database = connection['extinctlanguages']
collection = database['data']

print('connection created')
search_query = 'Italy'

def get_multiple_data():
    """
    get document data by document ID
    :return:
    """
    myquery = { "Countries": search_query }
    mydoc=collection.find(myquery)
    for i in mydoc:
         print(i)

# CLOSE DATABASE
get_multiple_data()
connection.close()

