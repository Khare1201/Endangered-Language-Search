import numpy as np

import pymongo
import gridfs
import cv2

# establish a connection to the database
connection = pymongo.MongoClient("mongodb+srv://user01:krtfall2019@shivam-c1-qds0d.mongodb.net/test?retryWrites=true&w=majority")

#get a handle to the test database
db = connection['extinctlanguages']
testCollection = db['imagesext']
file_meta = db.file_meta
file_used = ["image9.jpg"]
fs = gridfs.GridFS(db, 'imagesext') 
def main():
    
    for i in file_used:
         
        image=cv2.imread(i)
        imageString = image.tostring()

# store the image
        imageID = fs.put(imageString, encoding='utf-8')

        meta = {
        'name': i,
        'images': [
            {
                'imageID': imageID,
                'shape': image.shape,
                'dtype': str(image.dtype)
            }
        ]
        }

# insert the meta data

        testCollection.insert_one(meta)
    
    import random
  #  a=random.randint(1,6)
    image = testCollection.find_one({'name': 'image9.jpg'})['images'][0]

# get the image from gridfs
    gOut = fs.get(image['imageID'])

# convert bytes to ndarray
    img = np.frombuffer(gOut.read(), dtype=np.uint8)     
    img = np.reshape(img, image['shape'])    
    cv2.imshow('frame',img)
    cv2.waitKey(8000)

if __name__ == '__main__':
    main()