__author__ = 'Robbie'

search_placeholders = [
    "found in India...",
    "Indian Reservation...",
    "upper peninsula...",
    "Reservation in California...",
    "on the eastern coast...",
    "speakers have recently emigrated...",
    "an outlying dialect of...",
    "native speakers",
    "dialects in the area of....",
    "several villages",
    
]
