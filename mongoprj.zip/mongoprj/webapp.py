from functools import wraps
import logging
import random
import threading

from flask import Flask, request, session, url_for, redirect, render_template
from robly_mongo.user_mongo import UserMongo
from robly_crawler.crawler import get_website_object
from robly_parser.query_parser import QueryParser
from robly_mongo.website_mongo import WebsiteMongo
from robly_data.random_search_placeholder import search_placeholders
from robly_crawler import crawler
from robly_dto.website import Website
from duckduckgo.duckduckgo import query, Results, Result

from robly_mongo import connect_dbr

#Constants
_PORT = 9200
_HOST = '0.0.0.0'
_DEBUG = True

APP_NAME = "robbiesearch"   

webapp = Flask(__name__)


def check_loggied_in(func):
    @wraps(func)
    def wrapped_function(*args, **kwargs):
        if 'logged-in' in session:
            return func(*args, **kwargs)
        else:
            return redirect(url_for('login'))

    return wrapped_function

@webapp.route('/')
def root():
    if 'logged-in' in session:
        logged_in = True
    else:
        logged_in = False
    return render_template('index.html', title=APP_NAME, logged_in=logged_in,
                           rand_search=random.choice(search_placeholders))


@webapp.route('/index')
@check_loggied_in
def index():
    if 'logged-in' in session:
        logged_in = True
        return render_template('index.html', title=APP_NAME, logged_in=logged_in, name=session['username'],
                               rand_search=random.choice(search_placeholders))
    else:
        logged_in = False
        return render_template('index.html', title=APP_NAME, logged_in=logged_in,
                               rand_search=random.choice(search_placeholders))


@webapp.route('/search2', methods=["POST"])
def search2():
    """
    Insert comment from user into database and display it
    :return: HTML page displaying updated comment
    """
    if request.method == 'POST':
        query1 = request.form['comments']
        query2 = int(request.form['myFile'])
        query1=query1.strip()
        results = list() # Stores text info
       
       
        query_results = connect_dbr.get_multiple_data3(query1,query2)
        import json      
        query_results=json.loads(query_results)
        # Parsing through results from database and adding details to results
        for query_result in query_results:
           
            lat, long = get_geo_info(query_result["Countries"])
            indiv_result = [query_result["ID"], query_result["Name in English"],
                            query_result["Name in French"], query_result["Countries"],
                            query_result["Country codes alpha 3"], query_result["ISO639-3 codes"],
                            query_result["Degree of endangerment"], query_result["Alternate names"],
                            query_result["Number of speakers"], query_result["Description of the location"],
                            lat, long,query_result["comment"]]
            results.append(indiv_result)
        

        # Retrieve updated details
       

        # Parsing through query output and adding them to results
       
            
    return render_template("display.html", results=results)

@webapp.route('/signup')
def signup():
    """
    Displays the signup form for potential new users.
    """
    return render_template('index.html', rand_search=random.choice(search_placeholders), logged_in=is_logged_in())


@webapp.route('/login', methods=["GET", "POST"])
def login():
    """
    Displays the login form for potential new users.
    """
    if request.method == "GET":
        if 'logged-in' in session:
            return render_template('/index.html', logged_in=True,
                                   rand_search=random.choice(search_placeholders))
        else:
            return render_template('/index.html', logged_in=False,
                                   rand_search=random.choice(search_placeholders))

    else:
        mongo = UserMongo()
        email = request.form['email']
        password = request.form['password']
        user = mongo.read_user(email, password)
        if user:
            session['logged-in'] = True
            session['username'] = user.__getitem__("name")
            session['useremail'] = user.__getitem__("email")
            return redirect(url_for('index'))
        else:
            return "User not found"


@webapp.route('/logout')
@check_loggied_in
def logout():
    """
    Logs users out. Deletes the current session.
    Returns:
        Redirect - redirects to the login page.
    """
    session.pop('logged-in', None)
    session.pop('useremail', None)
    session.pop('username', None)
    return redirect(url_for('login'))


@webapp.route('/create_new_user', methods=["POST"])
def create_new_user():
    name = request.form['name']
    email = request.form['email']
    password = request.form['password']
    mongo = UserMongo()
    if mongo.create_user(name, email, password):
        return "User created successfully"
    else:
        return "User not created"


def get_websites_from_duckduckgo(search_query):
    """
    Called when no search results are found locally.
    Returns related results from DuckDuckGo's API
    """
    websites = []
    response = query(search_query,useragent='RoblySearch')
    related = response.related
    for r in related:
        try:
            w = Website(r.url,r.text,h1s=[],links=[],images=[],non_html=[],description=r.text,
                        keywords=[],robots_index=True)
            websites.append(w)
        except:
            pass
    return websites


@webapp.route('/search', methods=["POST"])
def search():
    DEBUG_INFO = "[ROBLY] webapp.py - /search - "
    #logging.debug(DEBUG_INFO + "POST request = " + request.form)
    query = request.form['search_box']
    query.strip()
    logging.debug(DEBUG_INFO + "query = " + query)

    #Create query parser object with query string provided by user
    #query_parser = QueryParser(query)
    #search_query, search_context = query_parser.extract_context_and_search_query()
    if len(query) > 1:
        #logging.debug(DEBUG_INFO + "SearchQuery = " + search_query)
        #logging.debug(DEBUG_INFO + "SearchContext = " + search_context)
        #query should now have been pruned of unnecessary words and characters
        #Get info from database
        #try:
            #mongo = WebsiteMongo()
            #logging.debug(DEBUG_INFO + "Attempthing to connect with mongodb searchquery='{}' "
            #                          "context=''".format(search_query, search_context))
            #websites, stats = mongo.search_websites(search_query, search_context)
            #convert microseconds to seconds
            #seconds = stats.time_micros / 1000000
        if request.form.get('location'):  
            lat, long = get_geo_info(query)
            myresults=connect_dbr.get_multiple_data2(lat,long)
        else:        
            myresults=connect_dbr.get_multiple_data(query)
        import json
        myresults=json.loads(myresults)
                   
            #Use duckduckgo api if no results found
            #if len(websites) < 1:
            #    websites = get_websites_from_duckduckgo(search_query)
            #else:
                #Add page rank to full text search score
            #    try:
            #        for w in websites:
            #            w.score += w.pagerank
            #    except:
            #        print("[ROBLY] Problem calculating search result score with page rank")
                #Sort list of websites by score
            #    from operator import attrgetter
            #    websites.sort(key=attrgetter('score'), reverse=False)
        return render_template('search_results.html', search_results=myresults)
        #except Exception as e:
        #    logging.error(DEBUG_INFO + "Error searching mongodb with the searchquery '{} - {}'".format(query,
        #                                                                                               str(e)))
        #    return redirect(url_for('index'))
    else:
        return redirect(url_for('index'))
        
import numpy as np

import pymongo
import gridfs
import cv2

# establish a connection to the database


#get a handle to the test database

def main():
    connection = pymongo.MongoClient("mongodb+srv://user01:krtfall2019@shivam-c1-qds0d.mongodb.net/test?retryWrites=true&w=majority")
    db = connection['extinctlanguages']
    testCollection = db['imagesext']
    file_meta = db.file_meta
    file_used = ["image1.jpg","image2.jpg","image3.jpg","image4.jpg","image5.jpg","image6.jpg","image7.jpg","image8.jpg","image9.jpg","image10.jpg"]
    fs = gridfs.GridFS(db, 'imagesext') 
    '''
    for i in file_used:
         
        image=cv2.imread(i)
        imageString = image.tostring()

# store the image
        imageID = fs.put(imageString, encoding='utf-8')

        meta = {
        'name': i,
        'images': [
            {
                'imageID': imageID,
                'shape': image.shape,
                'dtype': str(image.dtype)
            }
        ]
        }

# insert the meta data

        testCollection.insert_one(meta)
    '''
    import random
    a=random.randint(1,4)
    image = testCollection.find_one({'name': 'image'+str(a)+'.jpg'})['images'][0]

# get the image from gridfs
    gOut = fs.get(image['imageID'])

# convert bytes to ndarray
    img = np.frombuffer(gOut.read(), dtype=np.uint8)     
    img = np.reshape(img, image['shape'])    
    cv2.imwrite('static/a.jpg',img)
    connection.close()    
@webapp.route('/display_doc/<string:id>')
def display_doc(id):
    """
    Parse pet ID from anchor link URL and serve HTML page with pet document
    :param id: Pet ID
    :return: HTML page with respective pet document
    """
    if request.method == 'GET':
        results = list() # Stores text info
        image_results = list()
        imageID = list()

        query = id
        print(id)
        # Retrieve all details of the pet
        query_results = connect_dbr.get_multiple_data1(id)
        import json      
        query_results=json.loads(query_results)
        # Parsing through results from database and adding details to results
        for query_result in query_results:
           
            lat, long = get_geo_info(query_result["Countries"])
            indiv_result = [query_result["ID"], query_result["Name in English"],
                            query_result["Name in French"], query_result["Countries"],
                            query_result["Country codes alpha 3"], query_result["ISO639-3 codes"],
                            query_result["Degree of endangerment"], query_result["Alternate names"],
                            query_result["Number of speakers"], query_result["Description of the location"],
                            lat, long]
            results.append(indiv_result)
            main()
            '''
            if query_result["ID"] not in imageId:
                pet_ids.append(query_result["ID"])
                results.append(indiv_result)

            # Retrieving images from MongoDB
            for pet_id in pet_ids:
                indiv_pet_images = list()
                reg_exp = re.compile( + "-[0-9]+\.jpg", re.IGNORECASE)
                image_file = fs.find({"file_name": reg_exp})

            for im_file in image_file:
                image_b64 = codecs.encode(im_file.read(), 'base64')
                image = image_b64.decode('utf-8')
                indiv_pet_images.append(image)
            image_results.append(indiv_pet_images)

            all_results = zip(results, image_results)
            
            '''
    return render_template("doc_display.html", results=results,query=query)
"""

@webapp.route('/index_website', methods=["POST"])
def index_website():
    DEBUG_INFO = "[ROBLY] webapp.py - /index_website - "
    url = request.form['search_box']
    url.strip()
    logging.debug(DEBUG_INFO + "url = " + url)
    #Check if valid url
    if is_valid_url(url) and url.startswith('http'):
        logging.debug(DEBUG_INFO + "'{}' is a valid url")
        #Crawl website in a Thread
        t1 = threading.Thread(target=crawler.crawl_website_insert_to_database, args=(url,))
        t1.start()
        #Return the user to the index page while the thread is executing.
        return render_template('/index.html', logged_in=is_logged_in(),
                                rand_search=random.choice(search_placeholders),
                                index_message="'{} is being indexed and will be available to search in a few minutes.'".format(url))
    else:
        logging.error(DEBUG_INFO + "'{}' is not a valid url")
        return render_template('/index.html', logged_in=is_logged_in(),
                                rand_search=random.choice(search_placeholders),
                                index_message="Could not index the URL provided - {}".format(url))

@webapp.route('/error_indexing', methods=['GET'])
def error_indexing():
    return render_template('/index.html', logged_in=is_logged_in(),
                            rand_search=random.choice(search_placeholders),
                            index_message="Could not index the URL provided")


def is_valid_url(url):
"""
    
"""
    #Detects whether the given url is a valid url.
    import re
    regex = re.compile(
        r'^https?://'  # http:// or https://
        r'(?:(?:[A-Z0-9](?:[A-Z0-9-]{0,61}[A-Z0-9])?\.)+[A-Z]{2,6}\.?|'  # domain...
        r'localhost|'  # localhost...
        r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})' # ...or ip
        r'(?::\d+)?'  # optional port
        r'(?:/?|[/?]\S+)$', re.IGNORECASE)
    return url is not None and regex.search(url)


def is_empty(any_structure):
"""
#    Simple helper function to help determine if a robly_data
#    structure is empty.
#    Parameters:
##   Returns:
#        True - if the object is empty
#        False - if the object is not empty
"""
    if any_structure:
        return False
    else:
        return True

def is_logged_in():
    if 'logged-in' in session:
        return True
    else:
        return False


"""
from geopy.geocoders import Nominatim

def get_geo_info(Countries):
    """
    Retrieve Geographic co-ordinates based on state name
    :param state_name: Name of state
    :return: Latitude & Longitude
    """
    geo_loc = Nominatim(user_agent="user01")
    location = geo_loc.geocode({'country':Countries.split(" ")[0].strip()})
    return location.latitude, location.longitude

#If it's run directly by the python web system, start it
if __name__ == '__main__':
    #the secret key to encrypt and decrypt cookies
    webapp.secret_key = b'_0\xa5L\x0e\xd3"f\xfe\xbb\x07\xee\xebB?@\xaf.\xa6\xf0\xec\x19\x92\x95\xe6\xb2\xb4\xd1[ \xfad\x8bh\x93\xbf<b\xa5\xccV\xa4$%K4\xa8\xc4'
    webapp.run(host=_HOST, debug=_DEBUG, port=_PORT)    
    webapp.config['SEND_FILE_MAX_AGE_DEFAULT'] = 0
    #We do that because if we use app engine or tornado server
    #it calls it automatically, and uses different ports and namespaces
